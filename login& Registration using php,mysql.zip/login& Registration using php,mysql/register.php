<?php
// Connect to database
session_start();
$connection = mysqli_connect("localhost", "root", "", "Tech");

// Check connection
if (!$connection) {
    die("Unable to connect with MySQL server: " . mysqli_connect_error());
}

// Retrieve values from signup form
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$password = $_POST['password'];

// Query to insert new user into database
$query = "INSERT INTO Emp (firstname, lastname, email, password) VALUES ('$firstname', '$lastname', '$email', '$password')";

if (mysqli_query($connection, $query)) {
    // User registered successfully, redirect to welcome page
    $_SESSION["firstname"]= $firstname;
    header("Location: welcome.php?firstname=$firstname");
} else {
    // Error in registration, redirect back to signup page with error message
    header("Location: signupPage.php?error=1");
}

mysqli_close($connection);
?>
