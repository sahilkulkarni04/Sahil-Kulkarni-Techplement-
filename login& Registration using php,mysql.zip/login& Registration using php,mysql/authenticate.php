<?php
// Connect to database
session_start();


$connection = mysqli_connect("localhost", "root", "", "Tech");

// Check connection
if (!$connection) {
    die("Unable to connect with MySQL server: " . mysqli_connect_error());
}

// Retrieve values from login form
$email = $_POST['email'];
$password = $_POST['password'];

// Query to check if user exists
$query = "SELECT * FROM Emp where email='$email' and password='$password'" ;
$result = mysqli_query($connection, $query);

// Check if query was successful
if ($result) {
    // Check if any rows were returned
    if (mysqli_num_rows($result) > 0) {
        // User exists, redirect to welcome page
        $row = mysqli_fetch_assoc($result);
        
        $firstname = $row['Firstname'];
        $_SESSION["firstname"]= $firstname;
        header("Location: welcome.php?firstname=$firstname");

    } else {
        // User not found, redirect back to login page with error message
        header("Location: loginPage.php?error=1");
    }
} else {
    // Error in query execution, handle the error
    die("Query execution error: " . mysqli_error($connection));
}

// Close connection
mysqli_close($connection);
?>
