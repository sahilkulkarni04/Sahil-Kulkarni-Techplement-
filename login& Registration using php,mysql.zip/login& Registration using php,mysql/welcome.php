<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <style>
        body {
            background-color: lightorange;
        }
        .container {
            margin: auto;
            width: 50%;
            padding: 20px;
            background-color: lightgray;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        session_start();
        // Retrieve firstname from URL parameter
        $firstname = $_SESSION['firstname'];
        echo "<h2>Welcome, $firstname!</h2>";
        ?>
        <p>You have successfully logged in.</p>
    </div>
</body>
</html>
